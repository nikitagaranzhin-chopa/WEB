document.addEventListener('DOMContentLoaded', () => {
  const textarea = document.getElementById('arrayInputA');
  const result = document.getElementById('resultA');
  const calcBtn = document.getElementById('calcBtnA');
  const fillBtn = document.getElementById('fillBtnA');

  function parseNumbers(text) {
    const parts = text.trim().split(/\s+/);
    const values = [];

    for (let i = 0; i < parts.length; i += 1) {
      const value = Number(parts[i].replace(',', '.'));
      if (!Number.isFinite(value)) {
        return null;
      }
      values.push(value);
    }

    return values;
  }

  function calculateSumBetweenPiMatches(values) {
    const eps = 1e-5;
    let firstIndex = -1;
    let lastIndex = -1;

    for (let i = 0; i < values.length; i += 1) {
      if (Math.abs(values[i] - Math.PI) <= eps) {
        if (firstIndex === -1) {
          firstIndex = i;
        }
        lastIndex = i;
      }
    }

    if (firstIndex === -1 || firstIndex === lastIndex) {
      return null;
    }

    let sum = 0;
    for (let i = firstIndex + 1; i < lastIndex; i += 1) {
      sum += values[i];
    }

    return {
      firstIndex,
      lastIndex,
      sum,
    };
  }

  function showResult() {
    const text = textarea.value.trim();

    if (text.length === 0) {
      result.textContent = 'Ошибка: введите хотя бы один элемент массива.';
      result.classList.add('error');
      return;
    }

    const values = parseNumbers(text);
    if (!values) {
      result.textContent = 'Ошибка: массив должен содержать только действительные числа.';
      result.classList.add('error');
      return;
    }

    const calculation = calculateSumBetweenPiMatches(values);
    if (!calculation) {
      result.textContent = 'Недостаточно элементов, удовлетворяющих условию |x − π| ≤ 10^-5. Нужны как минимум первый и последний такой элементы.';
      result.classList.add('error');
      return;
    }

    result.innerHTML = `Первый подходящий элемент: <strong>${calculation.firstIndex}</strong>, последний: <strong>${calculation.lastIndex}</strong>.<br>Сумма элементов между ними: <strong>${calculation.sum}</strong>`;
    result.classList.remove('error');
  }

  calcBtn.addEventListener('click', showResult);
  fillBtn.addEventListener('click', () => {
    textarea.value = '5 3.1415926 7.2 9 -4 3.141593 11';
    showResult();
  });
});
