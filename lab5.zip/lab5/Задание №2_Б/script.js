document.addEventListener('DOMContentLoaded', () => {
  const textarea = document.getElementById('arrayInputB');
  const sourceArray = document.getElementById('sourceArray');
  const result = document.getElementById('resultB');
  const calcBtn = document.getElementById('calcBtnB');
  const fillBtn = document.getElementById('fillBtnB');

  function parseNumbers(text) {
    const parts = text.trim().split(/\s+/).filter(Boolean);
    const values = parts.map((item) => Number(item.replace(',', '.')));
    return values.every(Number.isFinite) ? values : null;
  }

  function hasOnlyOddDigits(number) {
    const value = Math.abs(Math.trunc(number));

    if (value === 0) {
      return false;
    }

    return String(value).split('').every((digit) => Number(digit) % 2 === 1);
  }

  function processArray() {
    const text = textarea.value.trim();

    if (!text) {
      result.textContent = 'Ошибка: введите массив действительных чисел.';
      result.classList.add('error');
      sourceArray.textContent = 'Пока пусто.';
      return;
    }

    const numbers = parseNumbers(text);
    if (!numbers) {
      result.textContent = 'Ошибка: массив должен содержать только корректные числа.';
      result.classList.add('error');
      sourceArray.textContent = 'Пока пусто.';
      return;
    }

    sourceArray.textContent = `[${numbers.join(', ')}]`;

    const filtered = numbers.filter((item) => !hasOnlyOddDigits(item));
    const removed = numbers.filter((item) => hasOnlyOddDigits(item));

    result.innerHTML = `Удалённые элементы: <strong>[${removed.join(', ')}]</strong><br>Новый массив: <strong>[${filtered.join(', ')}]</strong>`;
    result.classList.remove('error');
  }

  calcBtn.addEventListener('click', processArray);
  fillBtn.addEventListener('click', () => {
    textarea.value = '15.8 -31.2 24.9 7.1 802.5 -975.4 0.7 48.4 111.9';
    processArray();
  });
});
