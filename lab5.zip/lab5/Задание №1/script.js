document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('fibN');
  const result = document.getElementById('result');
  const calcBtn = document.getElementById('calcBtn');
  const fillBtn = document.getElementById('fillBtn');

  function fibonacci(n) {
    if (n === 1 || n === 2) {
      return 1n;
    }

    let prev = 1n;
    let current = 1n;

    for (let i = 3; i <= n; i += 1) {
      const next = prev + current;
      prev = current;
      current = next;
    }

    return current;
  }

  function showResult() {
    const n = Number(input.value);

    if (!Number.isInteger(n) || n < 1) {
      result.textContent = 'Ошибка: введите натуральное число N (N ≥ 1).';
      result.classList.add('error');
      return;
    }

    const value = fibonacci(n);
    result.textContent = `${n}-й член последовательности Фибоначчи: ${value.toString()}`;
    result.classList.remove('error');
  }

  calcBtn.addEventListener('click', showResult);
  fillBtn.addEventListener('click', () => {
    input.value = 10;
    showResult();
  });

  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      showResult();
    }
  });
});
