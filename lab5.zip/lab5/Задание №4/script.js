document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('wordInput');
  const result = document.getElementById('result');
  const calcBtn = document.getElementById('calcBtn');
  const fillBtn = document.getElementById('fillBtn');

  function transformWord(word) {
    let output = '';

    for (let i = 0; i < word.length; i += 1) {
      if ((i + 1) % 2 === 1) {
        output += word[i].toUpperCase();
      } else {
        output += word[i].toLowerCase();
      }
    }

    return output;
  }

  function showResult() {
    const word = input.value.trim();

    if (!word) {
      result.textContent = 'Ошибка: введите слово.';
      result.classList.add('error');
      return;
    }

    const transformed = transformWord(word);
    result.innerHTML = `Исходное слово: <strong>${word}</strong><br>Результат: <strong>${transformed}</strong>`;
    result.classList.remove('error');
  }

  calcBtn.addEventListener('click', showResult);
  fillBtn.addEventListener('click', () => {
    input.value = 'программирование';
    showResult();
  });

  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      showResult();
    }
  });
});
