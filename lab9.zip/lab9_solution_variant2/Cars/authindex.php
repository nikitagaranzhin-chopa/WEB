<?php
require_once __DIR__ . '/config/helpers.php';
require_auth();
$user = current_user();
$pageTitle = 'Личный кабинет';
require_once __DIR__ . '/incs/authheader.php';
?>
<section class="dashboard-grid">
    <article class="panel">
        <h1>Здравствуйте, <?= e($user['full_name']) ?>!</h1>
        <p>Вы вошли как <strong><?= $user['role'] === 'admin' ? 'администратор' : 'авторизованный пользователь' ?></strong>.</p>
        <p>Отсюда можно перейти к просмотру услуг, редактированию профиля и, при наличии прав, к управлению пользователями.</p>
        <div class="actions">
            <a class="btn btn-primary" href="authcars.php">Мои услуги</a>
            <a class="btn btn-secondary" href="person.php">Редактировать профиль</a>
        </div>
    </article>
    <article class="panel info-list">
        <h2>Ваши данные</h2>
        <dl>
            <div><dt>Логин</dt><dd><?= e($user['login']) ?></dd></div>
            <div><dt>Email</dt><dd><?= e($user['email']) ?></dd></div>
            <div><dt>Дата рождения</dt><dd><?= e($user['birth_date']) ?></dd></div>
            <div><dt>Телефон</dt><dd><?= e($user['phone'] ?: 'не указан') ?></dd></div>
        </dl>
    </article>
</section>
<?php require_once __DIR__ . '/incs/footer.php'; ?>
