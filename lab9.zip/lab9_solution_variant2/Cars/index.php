<?php
$pageTitle = 'Russian Cars Service';
$extraCss = ['cars.css'];
require_once __DIR__ . '/incs/header.php';
?>
<section class="hero">
    <div>
        <span class="badge">Подготовительный этап к курсовой</span>
        <h1>Сайт автосервиса и услуг для владельцев российских автомобилей</h1>
        <p class="lead">Эта лабораторная посвящена модулю управления пользователями: регистрации, авторизации, ролям и CRUD-операциям. Стиль и тема уже подготовлены под будущую курсовую работу.</p>
        <div class="actions">
            <a class="btn btn-primary" href="cars.php">Список услуг</a>
            <a class="btn btn-secondary" href="logReg.php">Войти или зарегистрироваться</a>
        </div>
    </div>
    <div class="hero-card">
        <h2>Что уже реализовано</h2>
        <ul class="feature-list">
            <li>Регистрация неавторизованных пользователей</li>
            <li>Авторизация и аутентификация</li>
            <li>Роли: администратор и пользователь</li>
            <li>Просмотр, редактирование и удаление пользователей</li>
            <li>Основа для дальнейшей курсовой работы</li>
        </ul>
    </div>
</section>

<section class="grid cards-grid">
    <article class="card">
        <h3>Диагностика</h3>
        <p>Проверка основных узлов и электронных систем автомобиля перед ремонтом.</p>
    </article>
    <article class="card">
        <h3>Плановое ТО</h3>
        <p>Замена масла, фильтров, свечей и других расходников.</p>
    </article>
    <article class="card">
        <h3>Подбор запчастей</h3>
        <p>Подбор оригинальных и совместимых комплектующих для российских авто.</p>
    </article>
</section>
<?php require_once __DIR__ . '/incs/footer.php'; ?>
