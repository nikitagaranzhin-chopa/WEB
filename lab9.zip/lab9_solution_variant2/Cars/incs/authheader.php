<?php
require_once __DIR__ . '/../config/helpers.php';
require_auth();
$user = current_user();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) : 'Личный кабинет' ?></title>
    <link rel="stylesheet" href="css/main.css">
    <?php if (!empty($extraCss ?? '')): ?>
        <?php foreach ((array)$extraCss as $cssFile): ?>
            <link rel="stylesheet" href="css/<?= e($cssFile) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="logo" href="authindex.php">Russian Cars Service</a>
        <nav class="nav">
            <a href="authindex.php">Кабинет</a>
            <a href="authcars.php">Услуги</a>
            <a href="person.php">Мои данные</a>
            <?php if ($user && $user['role'] === 'admin'): ?>
                <a href="admin.php">Пользователи</a>
            <?php endif; ?>
            <a href="11.php">Выход</a>
        </nav>
    </div>
</header>
<main class="page-main">
    <div class="container">
        <?php $flash = get_flash(); ?>
        <?php if ($flash): ?>
            <div class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>
