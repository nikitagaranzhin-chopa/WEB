<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function is_auth(): bool
{
    return isset($_SESSION['user_id']);
}

function current_user(): ?array
{
    static $user = false;

    if ($user !== false) {
        return $user;
    }

    if (!is_auth()) {
        $user = null;
        return null;
    }

    $stmt = db()->prepare('SELECT id, full_name, login, email, birth_date, phone, role, created_at FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc() ?: null;

    if ($user === null) {
        unset($_SESSION['user_id']);
    }

    return $user;
}

function is_admin(): bool
{
    $user = current_user();
    return $user !== null && $user['role'] === 'admin';
}

function require_auth(): void
{
    if (!is_auth()) {
        set_flash('error', 'Сначала выполните вход.');
        redirect('logReg.php');
    }
}

function require_admin(): void
{
    require_auth();
    if (!is_admin()) {
        set_flash('error', 'Недостаточно прав для доступа к разделу администратора.');
        redirect('authindex.php');
    }
}

function login_user(array $user): void
{
    $_SESSION['user_id'] = (int)$user['id'];
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], (bool)$params['secure'], (bool)$params['httponly']);
    }
    session_destroy();
}

function normalize_phone(string $phone): string
{
    return preg_replace('/\D+/', '', $phone) ?? '';
}

function validate_user_data(array $data, bool $passwordRequired = true, bool $checkRole = false): array
{
    $errors = [];

    if (trim($data['full_name'] ?? '') === '') {
        $errors['full_name'] = 'Введите ФИО.';
    }

    $login = trim($data['login'] ?? '');
    if ($login === '') {
        $errors['login'] = 'Введите логин.';
    } elseif (!preg_match('/^[A-Za-z0-9_\-]{3,30}$/', $login)) {
        $errors['login'] = 'Логин должен содержать 3-30 символов: буквы, цифры, _ или -.';
    }

    $email = trim($data['email'] ?? '');
    if ($email === '') {
        $errors['email'] = 'Введите email.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Некорректный email.';
    }

    $birthDate = trim($data['birth_date'] ?? '');
    if ($birthDate === '') {
        $errors['birth_date'] = 'Введите дату рождения.';
    }

    $phone = trim($data['phone'] ?? '');
    if ($phone !== '') {
        $digits = normalize_phone($phone);
        if (strlen($digits) < 10 || strlen($digits) > 15) {
            $errors['phone'] = 'Телефон должен содержать от 10 до 15 цифр.';
        }
    }

    $password = (string)($data['password'] ?? '');
    if ($passwordRequired && $password === '') {
        $errors['password'] = 'Введите пароль.';
    } elseif ($password !== '' && mb_strlen($password) < 6) {
        $errors['password'] = 'Пароль должен содержать не менее 6 символов.';
    }

    if ($checkRole) {
        $role = $data['role'] ?? 'user';
        if (!in_array($role, ['admin', 'user'], true)) {
            $errors['role'] = 'Некорректная роль.';
        }
    }

    return $errors;
}

function find_user_by_login(string $login): ?array
{
    $stmt = db()->prepare('SELECT * FROM users WHERE login = ? LIMIT 1');
    $stmt->bind_param('s', $login);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc() ?: null;
}
