<?php
declare(strict_types=1);

const DB_HOST = 'localhost';
const DB_NAME = 'russian_cars_lab9';
const DB_USER = 'root';
const DB_PASS = '';

function db(): mysqli
{
    static $mysqli = null;

    if ($mysqli === null) {
        $mysqli = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($mysqli->connect_errno) {
            http_response_code(500);
            exit('Ошибка подключения к MySQL. Проверьте config/db.php и импорт базы данных.');
        }
        $mysqli->set_charset('utf8mb4');
    }

    return $mysqli;
}
