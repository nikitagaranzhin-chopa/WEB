<?php
$pageTitle = 'Услуги';
$extraCss = ['cars.css'];
require_once __DIR__ . '/incs/header.php';
$services = [
    ['name' => 'Компьютерная диагностика', 'price' => '1 500 ₽', 'desc' => 'Чтение ошибок и проверка электронных систем.'],
    ['name' => 'Замена масла и фильтров', 'price' => '2 200 ₽', 'desc' => 'Плановое техническое обслуживание популярных моделей.'],
    ['name' => 'Ремонт подвески', 'price' => 'от 4 000 ₽', 'desc' => 'Диагностика и замена изношенных элементов подвески.'],
    ['name' => 'Шиномонтаж', 'price' => '1 800 ₽', 'desc' => 'Сезонная замена и балансировка колёс.'],
    ['name' => 'Предпродажная подготовка', 'price' => 'от 5 500 ₽', 'desc' => 'Комплексная проверка и подготовка автомобиля к продаже.'],
    ['name' => 'Подбор автомобиля', 'price' => 'от 7 000 ₽', 'desc' => 'Помощь в выборе и проверке автомобиля перед покупкой.'],
];
?>
<section class="section-heading">
    <h1>Наши услуги</h1>
    <p>Неавторизованные пользователи могут просматривать список услуг. Запись и дополнительный функционал будут расширены в курсовой.</p>
</section>
<div class="services-grid">
    <?php foreach ($services as $service): ?>
        <article class="service-card">
            <h3><?= e($service['name']) ?></h3>
            <p><?= e($service['desc']) ?></p>
            <div class="service-bottom">
                <strong><?= e($service['price']) ?></strong>
                <?php if (is_auth()): ?>
                    <a class="btn btn-primary small" href="authcars.php">Подробнее</a>
                <?php else: ?>
                    <a class="btn btn-secondary small" href="logReg.php">Войти</a>
                <?php endif; ?>
            </div>
        </article>
    <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/incs/footer.php'; ?>
