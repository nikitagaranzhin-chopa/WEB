<?php
require_once __DIR__ . '/config/helpers.php';
logout_user();
setcookie(session_name(), '', time() - 3600, '/');
header('Location: index.php');
exit;
