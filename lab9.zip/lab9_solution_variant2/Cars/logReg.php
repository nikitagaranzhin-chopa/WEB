<?php
require_once __DIR__ . '/config/helpers.php';

if (is_auth()) {
    redirect('authindex.php');
}

$registerErrors = [];
$loginErrors = [];
$registerData = ['full_name' => '', 'login' => '', 'email' => '', 'birth_date' => '', 'phone' => ''];
$loginValue = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'register') {
        $registerData = [
            'full_name' => trim($_POST['full_name'] ?? ''),
            'login' => trim($_POST['login'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'birth_date' => trim($_POST['birth_date'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'password' => (string)($_POST['password'] ?? ''),
        ];

        $registerErrors = validate_user_data($registerData, true, false);

        if (!$registerErrors) {
            $stmt = db()->prepare('SELECT id FROM users WHERE login = ? OR email = ? LIMIT 1');
            $stmt->bind_param('ss', $registerData['login'], $registerData['email']);
            $stmt->execute();
            if ($stmt->get_result()->fetch_assoc()) {
                $registerErrors['exists'] = 'Пользователь с таким логином или email уже существует.';
            }
        }

        if (!$registerErrors) {
            $hash = password_hash($registerData['password'], PASSWORD_DEFAULT);
            $role = 'user';
            $stmt = db()->prepare('INSERT INTO users (full_name, login, email, password, birth_date, phone, role) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $stmt->bind_param(
                'sssssss',
                $registerData['full_name'],
                $registerData['login'],
                $registerData['email'],
                $hash,
                $registerData['birth_date'],
                $registerData['phone'],
                $role
            );
            $stmt->execute();

            set_flash('success', 'Регистрация выполнена. Теперь войдите под своим логином и паролем.');
            redirect('logReg.php');
        }
    }

    if ($action === 'login') {
        $loginValue = trim($_POST['login'] ?? '');
        $password = (string)($_POST['password'] ?? '');

        if ($loginValue === '') {
            $loginErrors['login'] = 'Введите логин.';
        }
        if ($password === '') {
            $loginErrors['password'] = 'Введите пароль.';
        }

        if (!$loginErrors) {
            $stmt = db()->prepare('SELECT * FROM users WHERE login = ? LIMIT 1');
            $stmt->bind_param('s', $loginValue);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();

            if (!$user || !password_verify($password, $user['password'])) {
                $loginErrors['common'] = 'Неверный логин или пароль.';
            } else {
                login_user($user);
                set_flash('success', 'Вы успешно авторизовались.');
                redirect('authindex.php');
            }
        }
    }
}

$pageTitle = 'Вход и регистрация';
$extraCss = ['logReg.css'];
require_once __DIR__ . '/incs/header.php';
?>
<section class="auth-layout">
    <div class="auth-card">
        <h1>Вход</h1>
        <?php if (!empty($loginErrors['common'])): ?><div class="error-box"><?= e($loginErrors['common']) ?></div><?php endif; ?>
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="login">
            <label>
                Логин
                <input type="text" name="login" value="<?= e($loginValue) ?>">
                <?php if (!empty($loginErrors['login'])): ?><span class="field-error"><?= e($loginErrors['login']) ?></span><?php endif; ?>
            </label>
            <label>
                Пароль
                <input type="password" name="password">
                <?php if (!empty($loginErrors['password'])): ?><span class="field-error"><?= e($loginErrors['password']) ?></span><?php endif; ?>
            </label>
            <button class="btn btn-primary" type="submit">Войти</button>
        </form>
        <p class="hint">Тестовый администратор: <strong>admin</strong> / <strong>admin123</strong></p>
    </div>

    <div class="auth-card">
        <h2>Регистрация</h2>
        <?php if (!empty($registerErrors['exists'])): ?><div class="error-box"><?= e($registerErrors['exists']) ?></div><?php endif; ?>
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="register">
            <label>
                ФИО
                <input type="text" name="full_name" value="<?= e($registerData['full_name']) ?>">
                <?php if (!empty($registerErrors['full_name'])): ?><span class="field-error"><?= e($registerErrors['full_name']) ?></span><?php endif; ?>
            </label>
            <label>
                Логин
                <input type="text" name="login" value="<?= e($registerData['login']) ?>">
                <?php if (!empty($registerErrors['login'])): ?><span class="field-error"><?= e($registerErrors['login']) ?></span><?php endif; ?>
            </label>
            <label>
                Email
                <input type="email" name="email" value="<?= e($registerData['email']) ?>">
                <?php if (!empty($registerErrors['email'])): ?><span class="field-error"><?= e($registerErrors['email']) ?></span><?php endif; ?>
            </label>
            <label>
                Дата рождения
                <input type="date" name="birth_date" value="<?= e($registerData['birth_date']) ?>">
                <?php if (!empty($registerErrors['birth_date'])): ?><span class="field-error"><?= e($registerErrors['birth_date']) ?></span><?php endif; ?>
            </label>
            <label>
                Телефон
                <input type="text" name="phone" value="<?= e($registerData['phone']) ?>" placeholder="+7 (900) 000-00-00">
                <?php if (!empty($registerErrors['phone'])): ?><span class="field-error"><?= e($registerErrors['phone']) ?></span><?php endif; ?>
            </label>
            <label>
                Пароль
                <input type="password" name="password">
                <?php if (!empty($registerErrors['password'])): ?><span class="field-error"><?= e($registerErrors['password']) ?></span><?php endif; ?>
            </label>
            <button class="btn btn-primary" type="submit">Зарегистрироваться</button>
        </form>
    </div>
</section>
<?php require_once __DIR__ . '/incs/footer.php'; ?>
