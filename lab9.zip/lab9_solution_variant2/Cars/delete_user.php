<?php
require_once __DIR__ . '/config/helpers.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin.php');
}

$id = (int)($_POST['id'] ?? 0);
$currentId = (int)current_user()['id'];

if ($id <= 0 || $id === $currentId) {
    set_flash('error', 'Нельзя удалить эту запись.');
    redirect('admin.php');
}

$stmt = db()->prepare('DELETE FROM users WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();

set_flash('success', 'Пользователь удалён.');
redirect('admin.php');
