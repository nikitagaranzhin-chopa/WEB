<?php
require_once __DIR__ . '/config/helpers.php';
require_auth();
$pageTitle = 'Услуги для авторизованных пользователей';
$extraCss = ['cars.css'];
require_once __DIR__ . '/incs/authheader.php';
$services = [
    ['name' => 'Диагностика двигателя', 'price' => '1 500 ₽', 'bonus' => 'Доступен просмотр истории обращений.'],
    ['name' => 'Плановое ТО', 'price' => '2 200 ₽', 'bonus' => 'В курсовой здесь будет запись на дату и время.'],
    ['name' => 'Подбор запчастей', 'price' => 'от 1 000 ₽', 'bonus' => 'Администратор позже сможет добавлять услуги.'],
];
?>
<section class="section-heading">
    <h1>Услуги в личном кабинете</h1>
    <p>Сейчас это демонстрационный список. На этапе курсовой сюда логично добавить онлайн-заявку и хранение заказанных услуг.</p>
</section>
<div class="services-grid">
    <?php foreach ($services as $service): ?>
        <article class="service-card service-card-auth">
            <h3><?= e($service['name']) ?></h3>
            <p>Цена: <strong><?= e($service['price']) ?></strong></p>
            <p><?= e($service['bonus']) ?></p>
        </article>
    <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/incs/footer.php'; ?>
