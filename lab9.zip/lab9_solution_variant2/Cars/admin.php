<?php
require_once __DIR__ . '/config/helpers.php';
require_admin();

$errors = [];
$addData = ['full_name' => '', 'login' => '', 'email' => '', 'birth_date' => '', 'phone' => '', 'role' => 'user', 'password' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_user') {
    $addData = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'login' => trim($_POST['login'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'birth_date' => trim($_POST['birth_date'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'role' => trim($_POST['role'] ?? 'user'),
        'password' => (string)($_POST['password'] ?? ''),
    ];

    $errors = validate_user_data($addData, true, true);

    if (!$errors) {
        $stmt = db()->prepare('SELECT id FROM users WHERE login = ? OR email = ? LIMIT 1');
        $stmt->bind_param('ss', $addData['login'], $addData['email']);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) {
            $errors['exists'] = 'Пользователь с таким логином или email уже существует.';
        }
    }

    if (!$errors) {
        $hash = password_hash($addData['password'], PASSWORD_DEFAULT);
        $stmt = db()->prepare('INSERT INTO users (full_name, login, email, password, birth_date, phone, role) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('sssssss', $addData['full_name'], $addData['login'], $addData['email'], $hash, $addData['birth_date'], $addData['phone'], $addData['role']);
        $stmt->execute();
        set_flash('success', 'Новый пользователь добавлен.');
        redirect('admin.php');
    }
}

$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $search = '%' . $q . '%';
    $stmt = db()->prepare('SELECT id, full_name, login, email, birth_date, phone, role, created_at FROM users WHERE full_name LIKE ? OR login LIKE ? OR email LIKE ? ORDER BY id DESC');
    $stmt->bind_param('sss', $search, $search, $search);
    $stmt->execute();
    $usersResult = $stmt->get_result();
} else {
    $usersResult = db()->query('SELECT id, full_name, login, email, birth_date, phone, role, created_at FROM users ORDER BY id DESC');
}
$users = $usersResult->fetch_all(MYSQLI_ASSOC);

$pageTitle = 'Управление пользователями';
$extraCss = ['person.css'];
require_once __DIR__ . '/incs/authheader.php';
?>
<section class="admin-grid">
    <article class="panel">
        <h1>Пользователи</h1>
        <form class="search-bar" action="search_user.php" method="get">
            <input type="text" name="q" value="<?= e($q) ?>" placeholder="Поиск по ФИО, логину или email">
            <button class="btn btn-secondary" type="submit">Найти</button>
            <a class="btn btn-ghost" href="admin.php">Сбросить</a>
        </form>
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>ФИО</th>
                    <th>Логин</th>
                    <th>Email</th>
                    <th>Роль</th>
                    <th>Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($users as $tableUser): ?>
                    <tr>
                        <td><?= (int)$tableUser['id'] ?></td>
                        <td><?= e($tableUser['full_name']) ?></td>
                        <td><?= e($tableUser['login']) ?></td>
                        <td><?= e($tableUser['email']) ?></td>
                        <td><span class="role-badge role-<?= e($tableUser['role']) ?>"><?= e($tableUser['role']) ?></span></td>
                        <td class="actions-cell">
                            <a class="btn btn-secondary small" href="edit_user.php?id=<?= (int)$tableUser['id'] ?>">Изменить</a>
                            <?php if ((int)$tableUser['id'] !== (int)current_user()['id']): ?>
                                <form action="delete_user.php" method="post" onsubmit="return confirm('Удалить пользователя?');">
                                    <input type="hidden" name="id" value="<?= (int)$tableUser['id'] ?>">
                                    <button class="btn btn-danger small" type="submit">Удалить</button>
                                </form>
                            <?php else: ?>
                                <span class="muted">это вы</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$users): ?>
                    <tr><td colspan="6">Ничего не найдено.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </article>

    <aside class="panel">
        <h2>Добавить пользователя</h2>
        <?php if (!empty($errors['exists'])): ?><div class="error-box"><?= e($errors['exists']) ?></div><?php endif; ?>
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="add_user">
            <label>
                ФИО
                <input type="text" name="full_name" value="<?= e($addData['full_name']) ?>">
                <?php if (!empty($errors['full_name'])): ?><span class="field-error"><?= e($errors['full_name']) ?></span><?php endif; ?>
            </label>
            <label>
                Логин
                <input type="text" name="login" value="<?= e($addData['login']) ?>">
                <?php if (!empty($errors['login'])): ?><span class="field-error"><?= e($errors['login']) ?></span><?php endif; ?>
            </label>
            <label>
                Email
                <input type="email" name="email" value="<?= e($addData['email']) ?>">
                <?php if (!empty($errors['email'])): ?><span class="field-error"><?= e($errors['email']) ?></span><?php endif; ?>
            </label>
            <label>
                Дата рождения
                <input type="date" name="birth_date" value="<?= e($addData['birth_date']) ?>">
                <?php if (!empty($errors['birth_date'])): ?><span class="field-error"><?= e($errors['birth_date']) ?></span><?php endif; ?>
            </label>
            <label>
                Телефон
                <input type="text" name="phone" value="<?= e($addData['phone']) ?>">
                <?php if (!empty($errors['phone'])): ?><span class="field-error"><?= e($errors['phone']) ?></span><?php endif; ?>
            </label>
            <label>
                Роль
                <select name="role">
                    <option value="user" <?= $addData['role'] === 'user' ? 'selected' : '' ?>>user</option>
                    <option value="admin" <?= $addData['role'] === 'admin' ? 'selected' : '' ?>>admin</option>
                </select>
                <?php if (!empty($errors['role'])): ?><span class="field-error"><?= e($errors['role']) ?></span><?php endif; ?>
            </label>
            <label>
                Пароль
                <input type="password" name="password">
                <?php if (!empty($errors['password'])): ?><span class="field-error"><?= e($errors['password']) ?></span><?php endif; ?>
            </label>
            <button class="btn btn-primary" type="submit">Добавить</button>
        </form>
    </aside>
</section>
<?php require_once __DIR__ . '/incs/footer.php'; ?>
