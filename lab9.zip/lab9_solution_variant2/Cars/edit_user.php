<?php
require_once __DIR__ . '/config/helpers.php';
require_auth();

$current = current_user();
$targetId = isset($_GET['id']) ? (int)$_GET['id'] : $current['id'];

if (!is_admin() && $targetId !== (int)$current['id']) {
    set_flash('error', 'Вы можете редактировать только свои данные.');
    redirect('person.php');
}

$stmt = db()->prepare('SELECT id, full_name, login, email, birth_date, phone, role FROM users WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $targetId);
$stmt->execute();
$targetUser = $stmt->get_result()->fetch_assoc();

if (!$targetUser) {
    set_flash('error', 'Пользователь не найден.');
    redirect(is_admin() ? 'admin.php' : 'person.php');
}

$errors = [];
$data = $targetUser;
$data['password'] = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'login' => trim($_POST['login'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'birth_date' => trim($_POST['birth_date'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'password' => (string)($_POST['password'] ?? ''),
        'role' => is_admin() ? trim($_POST['role'] ?? $targetUser['role']) : $targetUser['role'],
    ];

    $errors = validate_user_data($data, false, is_admin());

    if (!$errors) {
        $stmt = db()->prepare('SELECT id FROM users WHERE (login = ? OR email = ?) AND id <> ? LIMIT 1');
        $stmt->bind_param('ssi', $data['login'], $data['email'], $targetId);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) {
            $errors['exists'] = 'Другой пользователь уже использует такой логин или email.';
        }
    }

    if (!$errors) {
        if ($data['password'] !== '') {
            $hash = password_hash($data['password'], PASSWORD_DEFAULT);
            $stmt = db()->prepare('UPDATE users SET full_name = ?, login = ?, email = ?, birth_date = ?, phone = ?, role = ?, password = ? WHERE id = ?');
            $stmt->bind_param('sssssssi', $data['full_name'], $data['login'], $data['email'], $data['birth_date'], $data['phone'], $data['role'], $hash, $targetId);
        } else {
            $stmt = db()->prepare('UPDATE users SET full_name = ?, login = ?, email = ?, birth_date = ?, phone = ?, role = ? WHERE id = ?');
            $stmt->bind_param('ssssssi', $data['full_name'], $data['login'], $data['email'], $data['birth_date'], $data['phone'], $data['role'], $targetId);
        }
        $stmt->execute();

        set_flash('success', 'Изменения сохранены.');
        redirect(is_admin() ? 'admin.php' : 'person.php');
    }
}

$pageTitle = 'Редактирование пользователя';
$extraCss = ['person.css'];
require_once __DIR__ . '/incs/authheader.php';
?>
<section class="profile-layout single-column">
    <article class="panel">
        <h1>Редактирование пользователя #<?= (int)$targetId ?></h1>
        <?php if (!empty($errors['exists'])): ?><div class="error-box"><?= e($errors['exists']) ?></div><?php endif; ?>
        <form method="post" class="form-grid profile-form">
            <label>
                ФИО
                <input type="text" name="full_name" value="<?= e($data['full_name']) ?>">
                <?php if (!empty($errors['full_name'])): ?><span class="field-error"><?= e($errors['full_name']) ?></span><?php endif; ?>
            </label>
            <label>
                Логин
                <input type="text" name="login" value="<?= e($data['login']) ?>">
                <?php if (!empty($errors['login'])): ?><span class="field-error"><?= e($errors['login']) ?></span><?php endif; ?>
            </label>
            <label>
                Email
                <input type="email" name="email" value="<?= e($data['email']) ?>">
                <?php if (!empty($errors['email'])): ?><span class="field-error"><?= e($errors['email']) ?></span><?php endif; ?>
            </label>
            <label>
                Дата рождения
                <input type="date" name="birth_date" value="<?= e($data['birth_date']) ?>">
                <?php if (!empty($errors['birth_date'])): ?><span class="field-error"><?= e($errors['birth_date']) ?></span><?php endif; ?>
            </label>
            <label>
                Телефон
                <input type="text" name="phone" value="<?= e($data['phone']) ?>">
                <?php if (!empty($errors['phone'])): ?><span class="field-error"><?= e($errors['phone']) ?></span><?php endif; ?>
            </label>
            <?php if (is_admin()): ?>
                <label>
                    Роль
                    <select name="role">
                        <option value="user" <?= $data['role'] === 'user' ? 'selected' : '' ?>>user</option>
                        <option value="admin" <?= $data['role'] === 'admin' ? 'selected' : '' ?>>admin</option>
                    </select>
                    <?php if (!empty($errors['role'])): ?><span class="field-error"><?= e($errors['role']) ?></span><?php endif; ?>
                </label>
            <?php endif; ?>
            <label>
                Новый пароль
                <input type="password" name="password" placeholder="Оставьте пустым, если пароль менять не нужно">
                <?php if (!empty($errors['password'])): ?><span class="field-error"><?= e($errors['password']) ?></span><?php endif; ?>
            </label>
            <div class="actions">
                <button class="btn btn-primary" type="submit">Сохранить</button>
                <a class="btn btn-secondary" href="<?= is_admin() ? 'admin.php' : 'person.php' ?>">Назад</a>
            </div>
        </form>
    </article>
</section>
<?php require_once __DIR__ . '/incs/footer.php'; ?>
