<?php
require_once __DIR__ . '/config/helpers.php';
require_auth();

$user = current_user();
$errors = [];
$data = [
    'full_name' => $user['full_name'],
    'login' => $user['login'],
    'email' => $user['email'],
    'birth_date' => $user['birth_date'],
    'phone' => $user['phone'],
    'password' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'login' => trim($_POST['login'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'birth_date' => trim($_POST['birth_date'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'password' => (string)($_POST['password'] ?? ''),
    ];

    $errors = validate_user_data($data, false, false);

    if (!$errors) {
        $stmt = db()->prepare('SELECT id FROM users WHERE (login = ? OR email = ?) AND id <> ? LIMIT 1');
        $stmt->bind_param('ssi', $data['login'], $data['email'], $user['id']);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) {
            $errors['exists'] = 'Другой пользователь уже использует такой логин или email.';
        }
    }

    if (!$errors) {
        if ($data['password'] !== '') {
            $hash = password_hash($data['password'], PASSWORD_DEFAULT);
            $stmt = db()->prepare('UPDATE users SET full_name = ?, login = ?, email = ?, birth_date = ?, phone = ?, password = ? WHERE id = ?');
            $stmt->bind_param('ssssssi', $data['full_name'], $data['login'], $data['email'], $data['birth_date'], $data['phone'], $hash, $user['id']);
        } else {
            $stmt = db()->prepare('UPDATE users SET full_name = ?, login = ?, email = ?, birth_date = ?, phone = ? WHERE id = ?');
            $stmt->bind_param('sssssi', $data['full_name'], $data['login'], $data['email'], $data['birth_date'], $data['phone'], $user['id']);
        }
        $stmt->execute();

        set_flash('success', 'Ваши данные успешно обновлены.');
        redirect('person.php');
    }
}

$pageTitle = 'Мои данные';
$extraCss = ['person.css'];
require_once __DIR__ . '/incs/authheader.php';
?>
<section class="profile-layout">
    <article class="panel">
        <h1>Редактирование профиля</h1>
        <?php if (!empty($errors['exists'])): ?><div class="error-box"><?= e($errors['exists']) ?></div><?php endif; ?>
        <form method="post" class="form-grid profile-form">
            <label>
                ФИО
                <input type="text" name="full_name" value="<?= e($data['full_name']) ?>">
                <?php if (!empty($errors['full_name'])): ?><span class="field-error"><?= e($errors['full_name']) ?></span><?php endif; ?>
            </label>
            <label>
                Логин
                <input type="text" name="login" value="<?= e($data['login']) ?>">
                <?php if (!empty($errors['login'])): ?><span class="field-error"><?= e($errors['login']) ?></span><?php endif; ?>
            </label>
            <label>
                Email
                <input type="email" name="email" value="<?= e($data['email']) ?>">
                <?php if (!empty($errors['email'])): ?><span class="field-error"><?= e($errors['email']) ?></span><?php endif; ?>
            </label>
            <label>
                Дата рождения
                <input type="date" name="birth_date" value="<?= e($data['birth_date']) ?>">
                <?php if (!empty($errors['birth_date'])): ?><span class="field-error"><?= e($errors['birth_date']) ?></span><?php endif; ?>
            </label>
            <label>
                Телефон
                <input type="text" name="phone" value="<?= e($data['phone']) ?>">
                <?php if (!empty($errors['phone'])): ?><span class="field-error"><?= e($errors['phone']) ?></span><?php endif; ?>
            </label>
            <label>
                Новый пароль
                <input type="password" name="password" placeholder="Оставьте пустым, если не хотите менять">
                <?php if (!empty($errors['password'])): ?><span class="field-error"><?= e($errors['password']) ?></span><?php endif; ?>
            </label>
            <button class="btn btn-primary" type="submit">Сохранить изменения</button>
        </form>
    </article>
    <aside class="panel side-note">
        <h2>Права пользователя</h2>
        <ul class="feature-list compact">
            <li>Просмотр своих данных</li>
            <li>Редактирование только собственной записи</li>
            <li>Просмотр списка услуг</li>
        </ul>
    </aside>
</section>
<?php require_once __DIR__ . '/incs/footer.php'; ?>
