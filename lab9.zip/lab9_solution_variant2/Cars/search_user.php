<?php
require_once __DIR__ . '/config/helpers.php';
require_admin();
$q = trim($_GET['q'] ?? '');
redirect('admin.php?q=' . urlencode($q));
