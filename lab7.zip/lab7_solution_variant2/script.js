const display = document.getElementById('display');
const expression = document.getElementById('expression');
const keyboard = document.querySelector('.keyboard');

let currentValue = '0';
let firstOperand = null;
let operator = null;
let waitingForSecondOperand = false;
let errorState = false;

const operatorSigns = {
  '+': '+',
  '-': '−',
  '*': '×',
  '/': '÷'
};

function updateDisplay() {
  display.textContent = currentValue;

  if (errorState) {
    expression.textContent = 'Ошибка';
    return;
  }

  if (firstOperand !== null && operator) {
    expression.textContent = `${formatForExpression(firstOperand)} ${operatorSigns[operator]}`;
  } else {
    expression.innerHTML = '&nbsp;';
  }
}

function formatForExpression(number) {
  if (!Number.isFinite(number)) {
    return 'Ошибка';
  }

  const text = String(number);
  return text.length > 14 ? Number(number).toPrecision(10) : text;
}

function normalizeNumberString(text) {
  if (text === '-0') {
    return '0';
  }
  if (text.includes('.')) {
    text = text.replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '');
  }
  return text || '0';
}

function setCurrentFromNumber(number) {
  if (!Number.isFinite(number)) {
    showError();
    return;
  }

  const absValue = Math.abs(number);
  let text;

  if ((absValue !== 0 && absValue < 1e-8) || absValue > 1e12) {
    text = number.toExponential(8);
  } else {
    text = normalizeNumberString(String(Number(number.toFixed(10))));
  }

  currentValue = text;
}

function inputDigit(digit) {
  if (errorState) {
    clearAll();
  }

  if (waitingForSecondOperand) {
    currentValue = digit;
    waitingForSecondOperand = false;
    updateDisplay();
    return;
  }

  currentValue = currentValue === '0' ? digit : currentValue + digit;
  updateDisplay();
}

function inputDecimal() {
  if (errorState) {
    clearAll();
  }

  if (waitingForSecondOperand) {
    currentValue = '0.';
    waitingForSecondOperand = false;
    updateDisplay();
    return;
  }

  if (!currentValue.includes('.')) {
    currentValue += '.';
    updateDisplay();
  }
}

function clearEntry() {
  currentValue = '0';
  errorState = false;
  updateDisplay();
}

function clearAll() {
  currentValue = '0';
  firstOperand = null;
  operator = null;
  waitingForSecondOperand = false;
  errorState = false;
  updateDisplay();
}

function backspace() {
  if (errorState) {
    clearAll();
    return;
  }

  if (waitingForSecondOperand) {
    return;
  }

  if (currentValue.length <= 1 || (currentValue.length === 2 && currentValue.startsWith('-'))) {
    currentValue = '0';
  } else {
    currentValue = currentValue.slice(0, -1);
  }

  updateDisplay();
}

function toggleSign() {
  if (errorState) {
    return;
  }

  if (currentValue === '0') {
    return;
  }

  currentValue = currentValue.startsWith('-') ? currentValue.slice(1) : `-${currentValue}`;
  updateDisplay();
}

function calculate(first, second, op) {
  switch (op) {
    case '+': return first + second;
    case '-': return first - second;
    case '*': return first * second;
    case '/': return second === 0 ? NaN : first / second;
    default: return second;
  }
}

function handleOperator(nextOperator) {
  if (errorState) {
    return;
  }

  const inputValue = Number(currentValue);

  if (firstOperand === null) {
    firstOperand = inputValue;
  } else if (operator && !waitingForSecondOperand) {
    const result = calculate(firstOperand, inputValue, operator);
    if (!Number.isFinite(result)) {
      showError();
      return;
    }
    firstOperand = result;
    setCurrentFromNumber(result);
  }

  operator = nextOperator;
  waitingForSecondOperand = true;
  updateDisplay();
}

function handleEquals() {
  if (errorState || operator === null || firstOperand === null || waitingForSecondOperand) {
    return;
  }

  const leftOperand = firstOperand;
  const currentOperator = operator;
  const secondOperand = Number(currentValue);
  const result = calculate(leftOperand, secondOperand, currentOperator);

  if (!Number.isFinite(result)) {
    showError();
    return;
  }

  const finalExpression = `${formatForExpression(leftOperand)} ${operatorSigns[currentOperator]} ${formatForExpression(secondOperand)} =`;
  setCurrentFromNumber(result);
  firstOperand = null;
  operator = null;
  waitingForSecondOperand = false;
  updateDisplay();
  expression.textContent = finalExpression;
}

function showError() {
  currentValue = 'Ошибка';
  firstOperand = null;
  operator = null;
  waitingForSecondOperand = false;
  errorState = true;
  updateDisplay();
}

function handleSqrt() {
  if (errorState) {
    return;
  }

  const value = Number(currentValue);
  if (value < 0) {
    showError();
    return;
  }

  setCurrentFromNumber(Math.sqrt(value));
  updateDisplay();
}

function handleReciprocal() {
  if (errorState) {
    return;
  }

  const value = Number(currentValue);
  if (value === 0) {
    showError();
    return;
  }

  setCurrentFromNumber(1 / value);
  updateDisplay();
}

function handlePercent() {
  if (errorState) {
    return;
  }

  const value = Number(currentValue);
  let result = value / 100;

  if (firstOperand !== null && operator) {
    result = firstOperand * value / 100;
  }

  setCurrentFromNumber(result);
  waitingForSecondOperand = false;
  updateDisplay();
}

keyboard.addEventListener('click', (event) => {
  const button = event.target.closest('button');
  if (!button) {
    return;
  }

  const { digit, action, operator: buttonOperator } = button.dataset;

  if (digit) {
    inputDigit(digit);
    return;
  }

  if (buttonOperator) {
    handleOperator(buttonOperator);
    return;
  }

  switch (action) {
    case 'decimal': inputDecimal(); break;
    case 'clear-all': clearAll(); break;
    case 'clear-entry': clearEntry(); break;
    case 'backspace': backspace(); break;
    case 'sign': toggleSign(); break;
    case 'equals': handleEquals(); break;
    case 'sqrt': handleSqrt(); break;
    case 'reciprocal': handleReciprocal(); break;
    case 'percent': handlePercent(); break;
    default: break;
  }
});

document.addEventListener('keydown', (event) => {
  const key = event.key;

  if (/^\d$/.test(key)) {
    inputDigit(key);
    return;
  }

  switch (key) {
    case '.':
    case ',':
      event.preventDefault();
      inputDecimal();
      break;
    case '+':
      handleOperator('+');
      break;
    case '-':
      handleOperator('-');
      break;
    case '*':
      handleOperator('*');
      break;
    case '/':
      event.preventDefault();
      handleOperator('/');
      break;
    case '%':
      event.preventDefault();
      handlePercent();
      break;
    case 'Enter':
    case '=':
      event.preventDefault();
      handleEquals();
      break;
    case 'Backspace':
      event.preventDefault();
      backspace();
      break;
    case 'Delete':
      clearEntry();
      break;
    case 'Escape':
      clearAll();
      break;
    default:
      break;
  }
});

updateDisplay();
