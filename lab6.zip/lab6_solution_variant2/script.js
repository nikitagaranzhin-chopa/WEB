const form = document.getElementById('orderForm');
const resultCard = document.getElementById('resultCard');
const resultGrid = document.getElementById('resultGrid');

const fields = {
  name: document.getElementById('name'),
  surname: document.getElementById('surname'),
  email: document.getElementById('email'),
  phone: document.getElementById('phone'),
  city: document.getElementById('city'),
  category: document.getElementById('category'),
  size: document.getElementById('size'),
  color: document.getElementById('color'),
  quantity: document.getElementById('quantity'),
  deliveryDate: document.getElementById('delivery-date'),
  promo: document.getElementById('promo'),
  comment: document.getElementById('comment'),
  address: document.getElementById('address'),
  reference: document.getElementById('reference'),
  attachment: document.getElementById('attachment'),
  consent: document.getElementById('consent')
};

const deliveryGroup = document.getElementById('deliveryGroup');
const paymentGroup = document.getElementById('paymentGroup');
const consentGroup = document.getElementById('consentGroup');

const letterPattern = /^[A-Za-zА-Яа-яЁёІіЇїЄє\-\s]+$/;
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const promoPattern = /^[A-Za-zА-Яа-яЁё0-9-]{3,12}$/;
const today = new Date();
today.setHours(0, 0, 0, 0);

function getFieldContainer(element) {
  return element.closest('.field');
}

function getErrorElement(container) {
  return container ? container.querySelector('.error-text') : null;
}

function setFieldState(container, errorMessage) {
  const errorElement = getErrorElement(container);
  container.classList.remove('has-error', 'is-valid');

  if (errorMessage) {
    container.classList.add('has-error');
    if (errorElement) {
      errorElement.textContent = errorMessage;
    }
    return false;
  }

  container.classList.add('is-valid');
  if (errorElement) {
    errorElement.textContent = '';
  }
  return true;
}

function clearGroupState(group) {
  group.classList.remove('has-error', 'is-valid');
  const errorElement = group.querySelector('.error-text');
  if (errorElement) {
    errorElement.textContent = '';
  }
}

function setGroupState(group, errorMessage) {
  const errorElement = group.querySelector('.error-text');
  group.classList.remove('has-error', 'is-valid');

  if (errorMessage) {
    group.classList.add('has-error');
    errorElement.textContent = errorMessage;
    return false;
  }

  group.classList.add('is-valid');
  errorElement.textContent = '';
  return true;
}

function trimValue(element) {
  return element.value.trim();
}

function validateTextField(element, minLength = 2) {
  const value = trimValue(element);
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, 'Поле обязательно для заполнения.');
  }

  if (value.length < minLength) {
    return setFieldState(container, `Минимальная длина — ${minLength} символа(ов).`);
  }

  if (!letterPattern.test(value)) {
    return setFieldState(container, 'Допустимы только буквы, пробел и дефис.');
  }

  return setFieldState(container, '');
}

function validateEmail(element) {
  const value = trimValue(element);
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, 'Поле обязательно для заполнения.');
  }

  if (!emailPattern.test(value)) {
    return setFieldState(container, 'Введите корректный адрес электронной почты.');
  }

  return setFieldState(container, '');
}

function validatePhone(element) {
  const value = trimValue(element);
  const digits = value.replace(/\D/g, '');
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, 'Поле обязательно для заполнения.');
  }

  if (digits.length < 10 || digits.length > 15) {
    return setFieldState(container, 'Телефон должен содержать от 10 до 15 цифр.');
  }

  return setFieldState(container, '');
}

function validateSelect(element) {
  const container = getFieldContainer(element);

  if (!element.value) {
    return setFieldState(container, 'Выберите значение из списка.');
  }

  return setFieldState(container, '');
}

function validateQuantity(element) {
  const value = trimValue(element);
  const number = Number(value);
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, 'Поле обязательно для заполнения.');
  }

  if (!Number.isInteger(number) || number < 1 || number > 20) {
    return setFieldState(container, 'Количество должно быть целым числом от 1 до 20.');
  }

  return setFieldState(container, '');
}

function validateDate(element) {
  const value = trimValue(element);
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, 'Выберите дату доставки.');
  }

  const selectedDate = new Date(value);
  selectedDate.setHours(0, 0, 0, 0);

  if (selectedDate < today) {
    return setFieldState(container, 'Дата доставки не может быть раньше сегодняшнего дня.');
  }

  return setFieldState(container, '');
}

function validateOptionalPromo(element) {
  const value = trimValue(element);
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, '');
  }

  if (!promoPattern.test(value)) {
    return setFieldState(container, 'Промокод: от 3 до 12 символов, буквы, цифры и дефис.');
  }

  return setFieldState(container, '');
}

function validateComment(element) {
  const value = trimValue(element);
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, '');
  }

  if (value.length < 5) {
    return setFieldState(container, 'Комментарий должен содержать минимум 5 символов.');
  }

  if (value.length > 300) {
    return setFieldState(container, 'Комментарий не должен превышать 300 символов.');
  }

  return setFieldState(container, '');
}

function validateAddress(element) {
  const value = trimValue(element);
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, 'Поле обязательно для заполнения.');
  }

  if (value.length < 5) {
    return setFieldState(container, 'Введите более полный адрес доставки.');
  }

  return setFieldState(container, '');
}

function validateUrl(element) {
  const value = trimValue(element);
  const container = getFieldContainer(element);

  if (!value) {
    return setFieldState(container, '');
  }

  try {
    const url = new URL(value);
    if (!/^https?:$/.test(url.protocol)) {
      throw new Error('Invalid protocol');
    }
  } catch (error) {
    return setFieldState(container, 'Введите корректную ссылку, начинающуюся с http:// или https://');
  }

  return setFieldState(container, '');
}

function validateAttachment(element) {
  const container = getFieldContainer(element);
  const file = element.files[0];

  if (!file) {
    return setFieldState(container, '');
  }

  if (!file.type.startsWith('image/')) {
    return setFieldState(container, 'Можно прикреплять только изображения.');
  }

  if (file.size > 5 * 1024 * 1024) {
    return setFieldState(container, 'Размер файла не должен превышать 5 МБ.');
  }

  return setFieldState(container, '');
}

function validateDelivery() {
  const checked = form.querySelector('input[name="delivery"]:checked');
  return setGroupState(deliveryGroup, checked ? '' : 'Выберите способ доставки.');
}

function validatePayment() {
  const checked = form.querySelectorAll('input[name="payment"]:checked');
  return setGroupState(paymentGroup, checked.length ? '' : 'Выберите хотя бы один способ оплаты.');
}

function validateConsent() {
  return setGroupState(consentGroup, fields.consent.checked ? '' : 'Необходимо подтвердить согласие на обработку данных.');
}

function normalizeTextInputs() {
  ['name', 'surname', 'city', 'color', 'promo', 'address', 'comment', 'reference', 'email', 'phone'].forEach((key) => {
    if (fields[key] && typeof fields[key].value === 'string') {
      fields[key].value = fields[key].value.trim();
    }
  });
}

function toggleMobileSelectColor(element) {
  if (element.value) {
    element.classList.add('has-value');
  } else {
    element.classList.remove('has-value');
  }
}

function validateForm() {
  normalizeTextInputs();

  const results = [
    validateTextField(fields.name),
    validateTextField(fields.surname),
    validateEmail(fields.email),
    validatePhone(fields.phone),
    validateTextField(fields.city),
    validateSelect(fields.category),
    validateSelect(fields.size),
    validateTextField(fields.color),
    validateQuantity(fields.quantity),
    validateDate(fields.deliveryDate),
    validateOptionalPromo(fields.promo),
    validateComment(fields.comment),
    validateAddress(fields.address),
    validateUrl(fields.reference),
    validateAttachment(fields.attachment),
    validateDelivery(),
    validatePayment(),
    validateConsent()
  ];

  return results.every(Boolean);
}

function createResultItem(label, value) {
  const item = document.createElement('div');
  item.className = 'result-item';

  const labelElement = document.createElement('div');
  labelElement.className = 'result-label';
  labelElement.textContent = label;

  const valueElement = document.createElement('div');
  valueElement.className = 'result-value';
  valueElement.textContent = value || '—';

  item.append(labelElement, valueElement);
  return item;
}

function renderResult() {
  const delivery = form.querySelector('input[name="delivery"]:checked');
  const payments = Array.from(form.querySelectorAll('input[name="payment"]:checked')).map((item) => item.value);
  const file = fields.attachment.files[0];

  const resultData = [
    ['Имя', trimValue(fields.name)],
    ['Фамилия', trimValue(fields.surname)],
    ['Электронная почта', trimValue(fields.email)],
    ['Телефон', trimValue(fields.phone)],
    ['Город', trimValue(fields.city)],
    ['Категория товара', fields.category.value],
    ['Размер', fields.size.value],
    ['Цвет', trimValue(fields.color)],
    ['Количество', fields.quantity.value],
    ['Желаемая дата доставки', fields.deliveryDate.value],
    ['Промокод', trimValue(fields.promo) || 'Не указан'],
    ['Комментарий', trimValue(fields.comment) || 'Не указан'],
    ['Адрес доставки', trimValue(fields.address)],
    ['Способ доставки', delivery ? delivery.value : '—'],
    ['Способ оплаты', payments.length ? payments.join(', ') : '—'],
    ['Ссылка на товар', trimValue(fields.reference) || 'Не указана'],
    ['Файл', file ? file.name : 'Не прикреплён']
  ];

  resultGrid.innerHTML = '';
  resultData.forEach(([label, value]) => {
    resultGrid.appendChild(createResultItem(label, value));
  });

  resultCard.classList.remove('is-hidden');
  resultCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function clearAllErrors() {
  form.querySelectorAll('.field').forEach((field) => {
    field.classList.remove('has-error', 'is-valid');
    const error = field.querySelector('.error-text');
    if (error) {
      error.textContent = '';
    }
  });

  [deliveryGroup, paymentGroup, consentGroup].forEach(clearGroupState);
}

function clearFormState() {
  clearAllErrors();
  form.querySelectorAll('select').forEach((select) => toggleMobileSelectColor(select));
}

form.addEventListener('submit', (event) => {
  event.preventDefault();

  if (!validateForm()) {
    const firstError = form.querySelector('.has-error input, .has-error select, .has-error textarea, .field-group.has-error');
    if (firstError && typeof firstError.focus === 'function') {
      firstError.focus();
    }
    return;
  }

  renderResult();
  form.reset();
  clearFormState();
});

form.addEventListener('reset', () => {
  window.setTimeout(() => {
    clearFormState();
  }, 0);
});

fields.name.addEventListener('blur', () => validateTextField(fields.name));
fields.surname.addEventListener('blur', () => validateTextField(fields.surname));
fields.email.addEventListener('blur', () => validateEmail(fields.email));
fields.phone.addEventListener('blur', () => validatePhone(fields.phone));
fields.city.addEventListener('blur', () => validateTextField(fields.city));
fields.color.addEventListener('blur', () => validateTextField(fields.color));
fields.quantity.addEventListener('blur', () => validateQuantity(fields.quantity));
fields.deliveryDate.addEventListener('change', () => validateDate(fields.deliveryDate));
fields.promo.addEventListener('blur', () => validateOptionalPromo(fields.promo));
fields.comment.addEventListener('blur', () => validateComment(fields.comment));
fields.address.addEventListener('blur', () => validateAddress(fields.address));
fields.reference.addEventListener('blur', () => validateUrl(fields.reference));
fields.attachment.addEventListener('change', () => validateAttachment(fields.attachment));
fields.consent.addEventListener('change', validateConsent);

form.querySelectorAll('input[name="delivery"]').forEach((item) => {
  item.addEventListener('change', validateDelivery);
});

form.querySelectorAll('input[name="payment"]').forEach((item) => {
  item.addEventListener('change', validatePayment);
});

[fields.category, fields.size].forEach((select) => {
  toggleMobileSelectColor(select);
  select.addEventListener('change', () => {
    toggleMobileSelectColor(select);
    validateSelect(select);
  });
});
