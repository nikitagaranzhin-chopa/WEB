<?php
$monthNames = [1 => 'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
$dayNames = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
$today = new DateTime('today');

$month = isset($_GET['month']) && ctype_digit($_GET['month']) ? (int)$_GET['month'] : (int)$today->format('n');
$year = isset($_GET['year']) && preg_match('/^\d{4}$/', $_GET['year']) ? (int)$_GET['year'] : (int)$today->format('Y');

if ($month < 1 || $month > 12) {
    $month = (int)$today->format('n');
}
if ($year < 1970 || $year > 2100) {
    $year = (int)$today->format('Y');
}

function getHolidayDates(int $year): array
{
    return [
        "$year-01-01", "$year-01-02", "$year-01-03", "$year-01-04",
        "$year-01-05", "$year-01-06", "$year-01-07", "$year-01-08",
        "$year-02-23", "$year-03-08", "$year-05-01", "$year-05-09",
        "$year-06-12", "$year-11-04"
    ];
}

function renderCalendar(int $month, int $year, array $monthNames, array $dayNames, DateTime $today): string
{
    $firstDay = new DateTime(sprintf('%04d-%02d-01', $year, $month));
    $daysInMonth = (int)$firstDay->format('t');
    $startWeekDay = (int)$firstDay->format('N');
    $holidayDates = getHolidayDates($year);

    $html = '<table>';
    $html .= '<caption style="caption-side:top;font-weight:700;padding:0 0 14px;">' . $monthNames[$month] . ' ' . $year . '</caption>';
    $html .= '<tr>';
    foreach ($dayNames as $dayName) {
        $html .= '<th>' . $dayName . '</th>';
    }
    $html .= '</tr><tr>';

    for ($empty = 1; $empty < $startWeekDay; $empty++) {
        $html .= '<td></td>';
    }

    $weekDay = $startWeekDay;
    for ($day = 1; $day <= $daysInMonth; $day++, $weekDay++) {
        $dateString = sprintf('%04d-%02d-%02d', $year, $month, $day);
        $classes = [];
        $dayNumber = (int)(new DateTime($dateString))->format('N');

        if ($dayNumber >= 6) {
            $classes[] = 'weekend';
        }
        if (in_array($dateString, $holidayDates, true)) {
            $classes[] = 'holiday';
        }
        if ($dateString === $today->format('Y-m-d')) {
            $classes[] = 'today';
        }

        $classAttribute = $classes ? ' class="' . implode(' ', $classes) . '"' : '';
        $html .= '<td' . $classAttribute . '>' . $day . '</td>';

        if ($weekDay % 7 === 0 && $day !== $daysInMonth) {
            $html .= '</tr><tr>';
        }
    }

    while (($weekDay - 1) % 7 !== 0) {
        $html .= '<td></td>';
        $weekDay++;
    }

    $html .= '</tr></table>';
    return $html;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Лабораторная 8 — Задание 2</title>
    <link rel="stylesheet" href="normalize.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="page">
        <nav class="nav">
            <a href="8a.php">Задание 1</a>
            <a href="8b.php">Задание 2</a>
            <a href="lab8c.php">Задание 3</a>
        </nav>
        <section class="card">
            <header class="header">
                <h1>Календарь на месяц</h1>
                <p class="subtitle">Если параметры не заданы, выводится текущий месяц. Выходные и праздники выделяются цветом.</p>
            </header>

            <form method="get" class="form-grid">
                <div>
                    <label for="month">Месяц</label>
                    <select name="month" id="month">
                        <?php foreach ($monthNames as $number => $name): ?>
                            <option value="<?= $number; ?>" <?= $number === $month ? 'selected' : ''; ?>><?= $name; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="year">Год</label>
                    <input type="number" name="year" id="year" min="1970" max="2100" value="<?= htmlspecialchars((string)$year); ?>">
                </div>
                <div>
                    <button type="submit">Показать календарь</button>
                </div>
            </form>

            <div class="table-wrap">
                <?= renderCalendar($month, $year, $monthNames, $dayNames, $today); ?>
            </div>

            <div class="legend">
                <span class="badge">Обычный день</span>
                <span class="badge weekend">Суббота / воскресенье</span>
                <span class="badge holiday">Праздничный день</span>
                <span class="badge today">Сегодня</span>
            </div>

            <div class="note muted">
                Праздничные даты заданы как основные общепринятые нерабочие дни: 1–8 января, 23 февраля, 8 марта, 1 мая, 9 мая, 12 июня и 4 ноября.
            </div>
        </section>
    </main>
</body>
</html>
