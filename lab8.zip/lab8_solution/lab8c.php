<?php
$old = [
    'full_name' => $_GET['full_name'] ?? '',
    'login' => $_GET['login'] ?? '',
    'birth_date' => $_GET['birth_date'] ?? ''
];
$errors = [
    'full_name' => $_GET['error_full_name'] ?? '',
    'login' => $_GET['error_login'] ?? '',
    'password' => $_GET['error_password'] ?? '',
    'birth_date' => $_GET['error_birth_date'] ?? ''
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Лабораторная 8 — Задание 3</title>
    <link rel="stylesheet" href="normalize.css">
    <link rel="stylesheet" href="8c_style.css">
</head>
<body>
    <main class="wrapper">
        <section class="card">
            <h1>Регистрация пользователя</h1>
            <p class="subtitle">Форма и обработка формы выполнены средствами PHP.</p>

            <form action="reg_8c.php" method="post" novalidate>
                <div class="form-grid">
                    <div class="field full">
                        <label for="full_name">ФИО</label>
                        <input class="<?= $errors['full_name'] ? 'error' : ''; ?>" type="text" name="full_name" id="full_name" maxlength="120" value="<?= htmlspecialchars($old['full_name']); ?>" placeholder="Иванов Иван Иванович">
                        <span class="error-text"><?= htmlspecialchars($errors['full_name']); ?></span>
                    </div>

                    <div class="field">
                        <label for="login">Логин</label>
                        <input class="<?= $errors['login'] ? 'error' : ''; ?>" type="text" name="login" id="login" maxlength="30" value="<?= htmlspecialchars($old['login']); ?>" placeholder="user_login">
                        <span class="error-text"><?= htmlspecialchars($errors['login']); ?></span>
                    </div>

                    <div class="field">
                        <label for="password">Пароль</label>
                        <input class="<?= $errors['password'] ? 'error' : ''; ?>" type="password" name="password" id="password" maxlength="64" placeholder="Не менее 6 символов">
                        <span class="error-text"><?= htmlspecialchars($errors['password']); ?></span>
                    </div>

                    <div class="field">
                        <label for="birth_date">Дата рождения</label>
                        <input class="<?= $errors['birth_date'] ? 'error' : ''; ?>" type="date" name="birth_date" id="birth_date" value="<?= htmlspecialchars($old['birth_date']); ?>">
                        <span class="error-text"><?= htmlspecialchars($errors['birth_date']); ?></span>
                    </div>
                </div>

                <div class="actions">
                    <button type="submit">Зарегистрировать</button>
                    <a class="link-btn" href="lab8c.php">Очистить форму</a>
                </div>
            </form>
        </section>
    </main>
</body>
</html>
