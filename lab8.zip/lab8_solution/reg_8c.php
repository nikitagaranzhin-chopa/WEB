<?php
function redirectWithErrors(array $errors, array $old): void
{
    $params = [
        'full_name' => $old['full_name'] ?? '',
        'login' => $old['login'] ?? '',
        'birth_date' => $old['birth_date'] ?? ''
    ];

    foreach ($errors as $field => $message) {
        $params['error_' . $field] = $message;
    }

    header('Location: lab8c.php?' . http_build_query($params));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: lab8c.php');
    exit;
}

$fullName = trim($_POST['full_name'] ?? '');
$login = trim($_POST['login'] ?? '');
$password = trim($_POST['password'] ?? '');
$birthDate = trim($_POST['birth_date'] ?? '');

$old = [
    'full_name' => $fullName,
    'login' => $login,
    'birth_date' => $birthDate,
];
$errors = [];

if ($fullName === '') {
    $errors['full_name'] = 'Поле ФИО обязательно для заполнения.';
} elseif (!preg_match('/^[А-Яа-яЁёA-Za-z\-\s]{5,120}$/u', $fullName)) {
    $errors['full_name'] = 'ФИО должно содержать только буквы, пробелы и дефис.';
}

if ($login === '') {
    $errors['login'] = 'Введите логин.';
} elseif (!preg_match('/^[A-Za-z][A-Za-z0-9_]{3,29}$/', $login)) {
    $errors['login'] = 'Логин: от 4 до 30 символов, первая буква — латинская.';
}

if ($password === '') {
    $errors['password'] = 'Введите пароль.';
} elseif (mb_strlen($password) < 6) {
    $errors['password'] = 'Пароль должен быть не короче 6 символов.';
}

if ($birthDate === '') {
    $errors['birth_date'] = 'Укажите дату рождения.';
} else {
    $date = DateTime::createFromFormat('Y-m-d', $birthDate);
    $validDate = $date && $date->format('Y-m-d') === $birthDate;

    if (!$validDate) {
        $errors['birth_date'] = 'Некорректная дата рождения.';
    } elseif ($date > new DateTime('today')) {
        $errors['birth_date'] = 'Дата рождения не может быть в будущем.';
    }
}

if ($errors) {
    redirectWithErrors($errors, $old);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Лабораторная 8 — Результат регистрации</title>
    <link rel="stylesheet" href="normalize.css">
    <link rel="stylesheet" href="8c_style.css">
</head>
<body>
    <main class="wrapper">
        <section class="card">
            <h1>Регистрация выполнена</h1>
            <p class="subtitle">Данные успешно обработаны на стороне сервера с помощью PHP.</p>

            <div class="result">
                <h2>Введённые данные</h2>
                <dl>
                    <dt>ФИО</dt>
                    <dd><?= htmlspecialchars($fullName); ?></dd>

                    <dt>Логин</dt>
                    <dd><?= htmlspecialchars($login); ?></dd>

                    <dt>Пароль</dt>
                    <dd><?= str_repeat('•', max(6, mb_strlen($password))); ?></dd>

                    <dt>Дата рождения</dt>
                    <dd><?= htmlspecialchars(date('d.m.Y', strtotime($birthDate))); ?></dd>
                </dl>
            </div>

            <div class="actions">
                <a class="link-btn" href="lab8c.php">Вернуться к форме</a>
            </div>
        </section>
    </main>
</body>
</html>
