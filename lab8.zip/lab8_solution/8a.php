<?php
function renderMultiplicationTable(int $from = 0, int $to = 10): string
{
    $html = '<table>';
    $html .= '<tr><th>×</th>';
    for ($j = $from; $j <= $to; $j++) {
        $html .= '<th>' . $j . '</th>';
    }
    $html .= '</tr>';

    for ($i = $from; $i <= $to; $i++) {
        $html .= '<tr>';
        $html .= '<th class="row-head">' . $i . '</th>';
        for ($j = $from; $j <= $to; $j++) {
            $html .= '<td>' . ($i * $j) . '</td>';
        }
        $html .= '</tr>';
    }

    $html .= '</table>';
    return $html;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Лабораторная 8 — Задание 1</title>
    <link rel="stylesheet" href="normalize.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="page">
        <nav class="nav">
            <a href="8a.php">Задание 1</a>
            <a href="8b.php">Задание 2</a>
            <a href="lab8c.php">Задание 3</a>
        </nav>
        <section class="card">
            <header class="header">
                <h1>Таблица умножения от 0 до 10</h1>
                <p class="subtitle">Таблица сгенерирована средствами PHP в циклах.</p>
            </header>
            <div class="table-wrap">
                <?= renderMultiplicationTable(); ?>
            </div>
        </section>
    </main>
</body>
</html>
